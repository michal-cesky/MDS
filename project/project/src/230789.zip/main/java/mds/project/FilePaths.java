package mds.project;

public class FilePaths {

    public  final static String VIDEO_FROM_URL = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";

    public  final static String DASH_DIRECTORY = "D:\\MDS\\files\\project\\streams\\";

}
